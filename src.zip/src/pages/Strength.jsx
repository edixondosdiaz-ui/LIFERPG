import BackButton from '../components/BackButton'
import { useCallback, useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import * as api from '../services/api'
import VolumeChart from '../components/VolumeChart'

const DAYS = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']

// 1 = lunes ... 7 = domingo, en hora de Colombia
const todayWeekday = () => {
  const d = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Bogota' })).getDay()
  return d === 0 ? 7 : d
}

const fmt = (s) => `${s.weight_kg} kg × ${s.reps}`

function SetList({ title, sets, empty, accent }) {
  return (
    <div className="rounded-2xl border border-white/[.06] bg-card2/70 p-3">
      <p className="kicker mb-2 !text-[10px]" style={accent ? { color: accent } : undefined}>{title}</p>
      {sets.length
        ? <div className="space-y-1">{sets.map((s, i) => <p key={s.id} className="text-sm font-semibold"><span className="mr-2 text-[11px] text-sub">{i + 1}</span>{fmt(s)}</p>)}</div>
        : <p className="text-xs text-sub">{empty}</p>}
    </div>
  )
}

function ExerciseCard({ exercise, onDelete }) {
  const { refreshProfile } = useAuth()
  const [todaySets, setTodaySets] = useState([])
  const [lastSets, setLastSets] = useState([])
  const [volume, setVolume] = useState([])
  const [weight, setWeight] = useState('')
  const [reps, setReps] = useState('')
  const [msg, setMsg] = useState({ type: '', text: '' })

  const load = useCallback(async () => {
    const [t, l, v] = await Promise.all([
      api.listSetsToday(exercise.id),
      api.getLastSession(exercise.id),
      api.getVolume(exercise.id),
    ])
    setTodaySets(t)
    setLastSets(l)
    setVolume(v)
  }, [exercise.id])

  useEffect(() => { load() }, [load])

  async function addSet(e) {
    e.preventDefault()
    setMsg({ type: '', text: '' })
    try {
      const r = await api.logSet({ exerciseId: exercise.id, weightKg: Number(weight), reps: Number(reps) })
      setMsg(r.overload ? { type: 'pr', text: `Sobrecarga progresiva · +${r.xp_awarded} XP` } : { type: 'ok', text: `+${r.xp_awarded} XP` })
      setReps('')
      await Promise.all([load(), refreshProfile()])
    } catch (err) {
      setMsg({ type: 'err', text: err.message })
    }
  }

  // Variación del último día con registros frente al anterior (con los datos que ya trae getVolume)
  const n = volume.length
  const delta = n >= 2 && volume[n - 2].volume ? Math.round(((volume[n - 1].volume - volume[n - 2].volume) / volume[n - 2].volume) * 100) : null

  return (
    <div className="surface space-y-4 p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-base font-extrabold">{exercise.name}</h3>
          {delta !== null && (
            <span className={`mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-extrabold ${delta >= 0 ? 'bg-emerald-400/15 text-emerald-300' : 'bg-red-400/15 text-red-300'}`}>
              {delta >= 0 ? '▲' : '▼'} {Math.abs(delta)}% de volumen vs. sesión anterior
            </span>
          )}
        </div>
        <button onClick={onDelete} className="rounded-full bg-white/5 px-3 py-1 text-[11px] font-semibold text-sub transition hover:bg-red-400/15 hover:text-red-300 active:scale-95">Borrar</button>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <SetList title="Última vez" sets={lastSets} empty="Sin registros" />
        <SetList title="Hoy" sets={todaySets} empty="Aún nada" accent="#c084fc" />
      </div>

      <form onSubmit={addSet} className="flex gap-2">
        <input className="field" type="number" inputMode="decimal" min="0" step="0.5" placeholder="Kg" required value={weight} onChange={(e) => setWeight(e.target.value)} />
        <input className="field" type="number" inputMode="numeric" min="1" step="1" placeholder="Reps" required value={reps} onChange={(e) => setReps(e.target.value)} />
        <button className="btn flex-none !px-5 text-lg leading-none" aria-label="Agregar serie">+</button>
      </form>
      {msg.text && (
        <p key={msg.text + todaySets.length} className={`animate-pop rounded-xl px-3 py-2 text-xs font-bold ${msg.type === 'pr' ? 'bg-gradient-to-r from-pu/25 to-pu-dark/10 text-pu-light' : msg.type === 'ok' ? 'bg-pu/10 text-pu-light' : 'bg-red-400/10 text-red-300'}`}>
          {msg.text}
        </p>
      )}

      <VolumeChart data={volume} />
    </div>
  )
}

export default function Strength() {
  const [weekday, setWeekday] = useState(todayWeekday())
  const [exercises, setExercises] = useState([])
  const [name, setName] = useState('')
  const today = todayWeekday()

  const load = useCallback(async () => setExercises(await api.listExercises(weekday)), [weekday])
  useEffect(() => { load() }, [load])

  async function add(e) {
    e.preventDefault()
    if (!name.trim()) return
    await api.addExercise({ weekday, name })
    setName('')
    load()
  }

  async function remove(id) {
    if (confirm('¿Borrar este ejercicio y todas sus series?')) {
      await api.deleteExercise(id)
      load()
    }
  }

  return (
    <div className="space-y-5">
      <header>
        <BackButton to="/pilares" label="Pilares" />
        <p className="kicker mt-3 text-pu-light">Entrenamiento</p>
        <h1 className="text-2xl font-extrabold tracking-tight">Fuerza</h1>
      </header>

      <div className="flex gap-1.5 rounded-2xl border border-white/[.07] bg-card p-1.5">
        {DAYS.map((d, i) => {
          const on = weekday === i + 1
          return (
            <button key={d} onClick={() => setWeekday(i + 1)}
              className={`relative flex-1 rounded-xl py-2.5 text-[11px] font-bold transition active:scale-95 ${on ? 'bg-gradient-to-b from-pu-light to-pu-dark text-white shadow-[0_6px_18px_-6px_#a855f7]' : 'text-sub hover:text-ink'}`}>
              {d}
              {today === i + 1 && <i className={`absolute left-1/2 top-1 h-1 w-1 -translate-x-1/2 rounded-full ${on ? 'bg-white' : 'bg-pu'}`} />}
            </button>
          )
        })}
      </div>

      <form onSubmit={add} className="flex gap-2">
        <input className="field" placeholder="Nuevo ejercicio (ej: Press de banca)" value={name} onChange={(e) => setName(e.target.value)} />
        <button disabled={!name.trim()} className="btn flex-none">Agregar</button>
      </form>

      {exercises.length === 0 && (
        <div className="rounded-3xl border border-dashed border-line px-6 py-10 text-center">
          <p className="text-sm font-bold">Día libre por ahora</p>
          <p className="mt-1 text-xs text-sub">Agrega tu primer ejercicio para este día y empieza a registrar series.</p>
        </div>
      )}
      {exercises.map((ex) => (
        <ExerciseCard key={ex.id} exercise={ex} onDelete={() => remove(ex.id)} />
      ))}
    </div>
  )
}
